#!/bin/bash

module load vasp/6.2.1-gpu

export OMP_NUM_THREADS=1
export OMP_PLACES=threads
export OMP_PROC_BIND=spread


for i in {1..20}; do
	cd conf_$i
	
	cd 1
	srun -n 8 -c 32 --cpu-bind=cores --gpu-bind=none -G 8 --exclusive vasp_std

	cp CHGCAR ../2 
	cd ../2
	srun -n 8 -c 32 --cpu-bind=cores --gpu-bind=none -G 8 --exclusive vasp_std
	cd ../

	cd ../
done
