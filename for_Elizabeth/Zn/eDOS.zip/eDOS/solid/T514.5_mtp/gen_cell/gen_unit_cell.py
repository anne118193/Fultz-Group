import sys 

def gen_cell_hexagonal(a, c): 
        header = """Zn2
1.0
        {0:.12f}         {1:.12f}         0.0000000000
       {2:.12f}        {3:.12f}         0.0000000000
        0.0000000000         0.0000000000        {4:.12f}
   Zn  
    2\n""".format(a/2, -a*3**(1/2.)/2, a/2, a*3**(1./2)/2, c)
        footer = """Direct
  0.3333333333333357  0.6666666666666643  0.2500000000000000
  0.6666666666666643  0.3333333333333357  0.7500000000000000"""
        with open("infile.ucposcar", 'w') as f:
                f.write(header)
                f.write(footer)

if __name__ == "__main__":
        gen_cell_hexagonal(float(sys.argv[1]), float(sys.argv[2]))
